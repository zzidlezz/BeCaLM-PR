# for example

python main.py \
    data=stereoset \
    model=llama3.yaml \
    editor=BeCalm \
    data.n_edits=128 \
    data.batch_size=16 \
    model_device=cuda:0 \
    editor_device=cuda:0 \
    early_stop_patience=3 \
    +retain_loss=true


python main.py \
    data=stereoset \
    model=mistral.yaml \
    editor=BeCalm \
    data.n_edits=128 \
    data.batch_size=16 \
    model_device=cuda:0 \
    editor_device=cuda:0 \
    early_stop_patience=3 \
    +retain_loss=true


python main.py \
    data=stereoset \
    model=gemma.yaml \
    editor=BeCalm \
    data.n_edits=128 \
    data.batch_size=16 \
    model_device=cuda:0 \
    editor_device=cuda:0 \
    early_stop_patience=3 \
    +retain_loss=true


python main.py \
    data=stereoset \
    model=gpt2m.yaml \
    editor=BeCalm \
    data.n_edits=128 \
    data.batch_size=16 \
    model_device=cuda:0 \
    editor_device=cuda:0 \
    early_stop_patience=3 \
    +retain_loss=true
