from typing import Dict
from omegaconf import DictConfig
import math
import torch
import torch.nn as nn
from torch.nn.utils import clip_grad_norm_
from torch.utils.data import DataLoader
from editor.base import BaseEditor
from util import get_module, get_shape
import numpy as np
from nets import RunningMeanStd
from itertools import islice
from tqdm import tqdm
import os
import wandb
from typing import Dict, List

#新增
from data.base import make_loader
import logging
LOG = logging.getLogger(__name__)




from util import (
    get_module,
    get_shape,
    empty_cache,
    cross_entropy,
    kl_div,
    TracerDict,
)
def pad_tensor(tensor, target_length, dim=0, padding_value=0):

    tensor_length = tensor.size(dim)
    if tensor_length >= target_length:
        return tensor.narrow(dim, 0, target_length)
    else:
        padding = target_length - tensor_length
        pad_shape = list(tensor.shape)
        pad_shape[dim] = padding
        pad_tensor = torch.full(pad_shape, padding_value, dtype=tensor.dtype, device=tensor.device)
        mask = torch.cat([torch.ones(tensor_length, dtype=torch.float32, device=tensor.device),
                          torch.zeros(padding, dtype=torch.float32, device=tensor.device)], dim=0)
        return torch.cat([tensor, pad_tensor], dim=dim)


class BeCalm(BaseEditor):

    def __init__(
        self,
        config: DictConfig,
        model: nn.Module
    ):
        super().__init__(
            config,
            model
        )

        self.lifelong_normalizer = nn.ModuleDict({
            str(k): RunningMeanStd(
                k[0]+k[1],
            )
            for k, v in self.shape_counter.items()
        }).to(config.editor_device)



    def predict_param_shifts(self) -> Dict[str, torch.FloatTensor]:
        """
        Bias-Activated Subset Editing (BASE) version.
        - Pipeline unchanged: cache -> one solve -> edit/recover.
        - Change: select top-activated samples (per module) before closed-form solve.
        """


        # ====== BASE hyperparams (write inside function) ======
        keep_ratio = 1  
        min_keep = 16       
        max_keep = None     
        score_clip_quantile = 0.99  

        param_shifts = {}

        for module_idx, module_name in enumerate(self.config.model.edit_modules):

            # -------- 0) Basic info --------
            module = get_module(self.model, module_name)
            shape = get_shape(module)                 # [d_in, d_out]
            device = self.config.editor_device
            normalizer = self.lifelong_normalizer[str(shape)]

            # -------- 1) Read cache --------
            cache_dir = f"{self.config.editor.cache_dir}/{self.config.model.layers}"
            files = os.listdir(cache_dir)

            key_files = sorted(
                [os.path.join(cache_dir, f) for f in files
                if f.startswith(f"{module_idx}_") and f.endswith("_keys.pth")]
            )
            value_files = sorted(
                [os.path.join(cache_dir, f) for f in files
                if f.startswith(f"{module_idx}_") and f.endswith("_values_grad.pth")]
            )

            if len(key_files) == 0 or len(value_files) == 0:
                raise RuntimeError(f"[BASE] Empty cache for module {module_name}.")

            hidden_states = torch.cat([torch.load(f) for f in key_files], dim=0).to(device)  # [N, d_in]
            values_grad  = torch.cat([torch.load(f) for f in value_files], dim=0).to(device) # [N, d_out]

            for f in key_files:
                os.remove(f)
            for f in value_files:
                os.remove(f)
            if len(os.listdir(cache_dir)) == 0:
                os.rmdir(cache_dir)

            v_feature = torch.empty((0, shape[1]), device=device)
            activation_scores = torch.empty((0,), device=device)

            bs = self.config.editor.batch_size
            for start_idx in range(0, hidden_states.shape[0], bs):
                end_idx = start_idx + bs

                hidden_once = pad_tensor(hidden_states[start_idx:end_idx], bs, 0)  # [bs, d_in]
                grad_once   = pad_tensor(values_grad[start_idx:end_idx], bs, 0)    # [bs, d_out]

                with torch.no_grad():
                    z = torch.cat((hidden_once, grad_once), dim=-1)
                    z = normalizer(z)

                    hidden_hat, pseudo_values_hat = z.split([shape[0], shape[1]], dim=-1)

                    coeffs = - self.config.editor.lr * (hidden_hat * hidden_hat).sum(dim=-1, keepdim=True)  # [bs,1]

                  
                    score = coeffs.abs().squeeze(-1)  # [bs]

                v_feature = torch.cat((v_feature, coeffs * pseudo_values_hat), dim=0)          # [*, d_out]
                activation_scores = torch.cat((activation_scores, score), dim=0)               # [*]

            # truncate to real N (remove padding tail)
            N = hidden_states.shape[0]
            v_feature = v_feature[:N, :]
            activation_scores = activation_scores[:N]

          
            with torch.no_grad():
                if score_clip_quantile is not None and 0.0 < score_clip_quantile < 1.0:
                    q = torch.quantile(activation_scores, score_clip_quantile)
                    activation_scores = torch.clamp(activation_scores, max=q)

                k = int(keep_ratio * N)
                k = max(k, min_keep)
                if max_keep is not None:
                    k = min(k, max_keep)
                k = min(k, N)

                # if k == N, it degenerates to baseline (no change)
                if k < N:
                    topk_idx = torch.topk(activation_scores, k, largest=True).indices
                    H = hidden_states[topk_idx, :]   # [k, d_in]
                    V = v_feature[topk_idx, :]       # [k, d_out]
                else:
                    H = hidden_states
                    V = v_feature

                lam = 1.0  
                k = H.shape[0]
                I_k = torch.eye(k, device=device)

                S = I_k + (H @ H.T) / lam

             
                X = torch.linalg.solve(S, V)

                param_shift = (H.T @ X) / lam


            param_shifts[module_name] = param_shift.to(next(self.model.parameters()).device)

        return param_shifts

   
   


    def cache(self, tuples):
        """
        Cache activations and gradients for the paired edit inputs.
        tuples: {
            "edit": List[Dict[str, Tensor]],
            "unrelated": ...
        }
        """

        cache_dir = os.path.join(self.config.editor.cache_dir, self.config.model.layers)
        os.makedirs(cache_dir, exist_ok=True)

        edit_dicts = []

        for idx, t in enumerate(tuples["edit"]):

            # ---- Trace forward & backward on edit samples ----
            with TracerDict(
                self.model,
                self.config,
                t
            ) as tr:
                logits = self.model(**t, return_dict=True).logits
                assert logits.shape[0] % 2 == 0

                logits_anti = logits[: logits.shape[0] // 2]
                logits_stereo = logits[logits.shape[0] // 2 :]

                edit_dict = self.edit_loss_fn(
                    logits_anti,
                    t["labels"][: logits.shape[0] // 2],
                    logits_stereo,
                    t["labels"][logits.shape[0] // 2 :],
                )
                edit_dict["loss"].backward()
                edit_dicts.append(edit_dict)

            # ---- Save keys / values_grad for each editable module ----
            for module_idx, module_name in enumerate(self.config.model.edit_modules):
                shape = get_shape(get_module(self.model, module_name))

                keys = tr[module_name].keys.to(torch.float32).to(self.config.editor_device)
                values_grad = tr[module_name].values_grad.to(torch.float32).to(self.config.editor_device)

                self.lifelong_normalizer[str(shape)].update(torch.cat((keys, values_grad), -1))

                torch.save(keys, f"{cache_dir}/{module_idx}_{idx}_keys.pth")
                torch.save(values_grad, f"{cache_dir}/{module_idx}_{idx}_values_grad.pth")

        return edit_dicts





    def run(self, train_loader: DataLoader, valid_loader: DataLoader):
        """
        """
        print("************************")
        self.valid(valid_loader)
        # empty_cache(self.config.editor.cache_dir, self.config)
       









